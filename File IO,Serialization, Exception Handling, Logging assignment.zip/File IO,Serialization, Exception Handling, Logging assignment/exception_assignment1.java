package ayushi1;

public class exception_assignment1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ar[]= new int[4];
		System.out.println(ar[6]);
		
		
		

	}

}
